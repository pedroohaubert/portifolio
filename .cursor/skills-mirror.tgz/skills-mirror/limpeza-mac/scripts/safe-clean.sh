#!/bin/bash
# Limpeza automática: só o que se regenera sozinho ou é sobra comprovada.
# Uso: bash safe-clean.sh [--dry-run] [--log ARQUIVO]
#   --dry-run  mostra o que apagaria e quanto liberaria, sem apagar
#   --log      arquivo onde registrar "KB<TAB>caminho" de cada remoção
set -u
shopt -s nullglob dotglob
DRY=0
LOG="${TMPDIR:-/tmp}/limpeza-mac-deleted.log"
while [ $# -gt 0 ]; do
  case $1 in
    --dry-run) DRY=1 ;;
    --log) LOG=$2; shift ;;
    *) echo "opção desconhecida: $1" >&2; exit 2 ;;
  esac
  shift
done
H="$HOME"
AS="$H/Library/Application Support"
TOTAL=0

gbs() { awk -v k="$1" 'BEGIN { printf "%.2f GB", k / 1048576 }'; }
kb() { du -sk "$1" 2>/dev/null | cut -f1; }
free_kb() { df -k /System/Volumes/Data 2>/dev/null | awk 'NR == 2 { print $4 }'; }
running() { pgrep -f "/$1.app/Contents/MacOS/" >/dev/null 2>&1; }   # app aberto

# in_use <caminho>: algum processo usa o caminho? Olha o argv e os arquivos abertos/mapeados,
# porque um binário chamado por link (ex.: `claude`) não mostra o caminho real da versão no argv.
in_use() {
  pgrep -f "$1" >/dev/null 2>&1 && return 0
  if [ -d "$1" ]; then lsof -t +D "$1" >/dev/null 2>&1; else lsof -t -- "$1" >/dev/null 2>&1; fi
}

# Itens com menos de 10 MB não ganham linha própria: entram no resumo da seção.
SMALL_N=0
SMALL_KB=0
report() {
  if [ "$2" -lt 10240 ] && [ "$1" != parcial ]; then
    SMALL_N=$((SMALL_N + 1)); SMALL_KB=$((SMALL_KB + $2))
  else
    printf '  %-12s %9s  %s\n' "$1" "$(gbs "$2")" "$3"
  fi
}
flush_small() {
  [ "$SMALL_N" -gt 0 ] && printf '  %-12s %9s  + %d itens pequenos\n' "$([ "$DRY" = 1 ] && echo '[simulação]' || echo apagado)" "$(gbs "$SMALL_KB")" "$SMALL_N"
  SMALL_N=0
  SMALL_KB=0
}
section() { flush_small; printf '\n== %s\n' "$1"; }

# del <caminho>...: apaga (ou simula), mede o que saiu de fato e registra no log
del() {
  local p before after freed
  for p in "$@"; do
    [ -e "$p" ] || [ -L "$p" ] || continue
    before=$(kb "$p"); before=${before:-0}
    if [ "$DRY" = 1 ]; then
      report "[simulação]" "$before" "$p"
      TOTAL=$((TOTAL + before))
      continue
    fi
    rm -rf "$p" 2>/dev/null
    after=0
    if [ -e "$p" ] || [ -L "$p" ]; then after=$(kb "$p"); after=${after:-0}; fi
    freed=$((before - after))
    TOTAL=$((TOTAL + freed))
    printf '%s\t%s\n' "$freed" "$p" >> "$LOG"
    if [ "$after" -gt 0 ]; then report parcial "$freed" "$p (parte protegida ficou)"; else report apagado "$freed" "$p"; fi
  done
}

# linked_version <link> <pasta de versões>: nome da versão para onde o link aponta (vazio se não souber)
linked_version() {
  local link=$1 dir=$2 t
  t=$(readlink "$link" 2>/dev/null) || return 0
  case $t in /*) ;; *) t="$(dirname "$link")/$t" ;; esac
  case $t in "$dir"/*) t=${t#"$dir"/}; printf '%s' "${t%%/*}" ;; esac
}

# keep_current <pasta de versões> <versão atual>: apaga as outras, menos as que estão rodando
keep_current() {
  local dir=$1 cur=$2 v
  [ -d "$dir" ] || return 0
  if [ -z "$cur" ] || [ ! -e "$dir/$cur" ]; then
    echo "  pulei $dir (não achei a versão atual)"
    return 0
  fi
  for v in "$dir"/*; do
    [ "$(basename "$v")" = "$cur" ] && continue
    if in_use "$v"; then echo "  em uso, mantida: $v"; continue; fi
    del "$v"
  done
}

[ "$DRY" = 1 ] && echo "SIMULAÇÃO: nada será apagado." || mkdir -p "$(dirname "$LOG")"
FREE_BEFORE=$(free_kb)

section "Versões antigas de CLIs (mantém a que o link aponta)"
AG="$AS/Cursor/User/globalStorage/anysphere.cursor-agent-worker/agent-cli"
keep_current "$AG/.local/share/cursor-agent/versions" \
  "$(linked_version "$AG/.local/bin/cursor-agent" "$AG/.local/share/cursor-agent/versions")"
del "$AG"/*.tar.gz   # instaladores que o worker do Cursor deixou para trás
CA="$H/.local/share/cursor-agent/versions"
cur=$(linked_version "$H/.local/bin/cursor-agent" "$CA")
[ -n "$cur" ] || cur=$(linked_version "$H/.local/bin/agent" "$CA")
keep_current "$CA" "$cur"
keep_current "$H/.codex/packages/standalone/releases" \
  "$(linked_version "$H/.codex/packages/standalone/current" "$H/.codex/packages/standalone/releases")"
keep_current "$H/.local/share/claude/versions" \
  "$(linked_version "$H/.local/bin/claude" "$H/.local/share/claude/versions")"

section "Discord (versões antigas do app)"
if running Discord; then
  echo "  Discord aberto: pulei"
elif [ -d "$AS/discord" ]; then
  newest=$(find "$AS/discord" -mindepth 1 -maxdepth 1 -type d -name 'app-*' | sed 's|.*/app-||' \
    | sort -t. -k1,1n -k2,2n -k3,3n | tail -1)
  for a in "$AS/discord"/app-*; do [ "$a" = "$AS/discord/app-$newest" ] || del "$a"; done
  del "$AS/discord/download"
fi

section "Caches de apps fechados"
for pair in "Cursor:Cursor" "Visual Studio Code:Code"; do
  app=${pair%%:*}; dir="$AS/${pair#*:}"
  [ -d "$dir" ] || continue
  if running "$app"; then echo "  $app aberto: pulei"; continue; fi
  del "$dir/CachedData" "$dir/Cache" "$dir/Code Cache" "$dir/GPUCache" "$dir/logs"
done
if pgrep -if stremio >/dev/null 2>&1; then echo "  Stremio aberto: pulei"; else del "$AS/stremio-server/stremio-cache"; fi
if running Xcode; then echo "  Xcode aberto: pulei"; else del "$H/Library/Developer/Xcode/DerivedData"; fi

section "~/Library/Caches (menos apps abertos e navegadores do Playwright)"
OPEN=$(lsappinfo list 2>/dev/null | awk '
  /^ *[0-9]+\) "/ { match($0, /"[^"]*"/); name = substr($0, RSTART + 1, RLENGTH - 2); bid = "" }
  /bundleID="/ { match($0, /bundleID="[^"]*"/); bid = substr($0, RSTART + 10, RLENGTH - 11) }
  /type="(Foreground|UIElement)"/ { print name; if (bid != "") print bid }')
VENDORS=$(printf '%s\n' "$OPEN" | grep -E '^[a-z0-9-]+\.[A-Za-z0-9-]+\.' | grep -v '^com\.apple\.' | cut -d. -f1-2 | sort -u)
for c in "$H/Library/Caches"/*; do
  n=$(basename "$c")
  case $n in ms-playwright|.DS_Store) continue ;; esac
  printf '%s\n' "$OPEN" | grep -Fxq -- "$n" && continue
  skip=0
  while IFS= read -r v; do
    [ -n "$v" ] || continue
    case $n in "$v"|"$v".*) skip=1 ;; esac
  done <<< "$VENDORS"
  [ "$skip" = 1 ] && continue
  del "$c"
done

section "Caches de gerenciadores de pacotes"
# pm <comando> <pasta do cache> <limpeza...>: mede a pasta antes e depois da limpeza oficial
pm() {
  local name=$1 dir=$2 before after
  shift 2
  command -v "$name" >/dev/null 2>&1 && [ -n "$dir" ] && [ -d "$dir" ] || return 0
  before=$(kb "$dir"); before=${before:-0}
  if [ "$DRY" = 1 ]; then
    printf '  %-12s %9s  %s  (%s)\n' "[simulação]" "$(gbs "$before")" "$dir" "$*"
    TOTAL=$((TOTAL + before))
    return 0
  fi
  "$@" >/dev/null 2>&1
  after=$(kb "$dir"); after=${after:-0}
  TOTAL=$((TOTAL + before - after))
  printf '%s\t%s\n' "$((before - after))" "$dir ($*)" >> "$LOG"
  printf '  %-12s %9s  %s\n' limpo "$(gbs $((before - after)))" "$*"
}
pm uv "$(uv cache dir 2>/dev/null)" uv cache clean
pm npm "$(npm config get cache 2>/dev/null)/_cacache" npm cache clean --force
pm pnpm "$(pnpm store path 2>/dev/null)" pnpm store prune
pm bun "$H/.bun/install/cache" bun pm cache rm
pm yarn "$(yarn cache dir 2>/dev/null)" yarn cache clean
if command -v brew >/dev/null 2>&1; then
  if [ "$DRY" = 1 ]; then
    out=$(brew cleanup --prune=all -n 2>/dev/null | grep -i 'free' | sed 's/^==> //')
  else
    out=$(brew cleanup --prune=all 2>/dev/null | grep -i 'free' | sed 's/^==> //')
  fi
  printf '  %-12s %s\n' "brew cleanup" "${out:-nada para limpar}"
fi

section "Builds de desenvolvimento do Next.js (.next/dev e .next/cache)"
if pgrep -f "next-server|next dev|next/dist/bin/next" >/dev/null 2>&1; then
  echo "  Next.js rodando: pulei"
else
  while IFS= read -r d; do del "$d"; done < <(find "$H" -maxdepth 6 \
    \( -path "$H/Library" -o -path "$H/.Trash" -o -name node_modules -o -name .git \) -prune \
    -o -type d \( -path "*/.next/dev" -o -path "*/.next/cache" \) -print -prune 2>/dev/null)
fi

section "Apps em Downloads iguais aos já instalados"
appver() { /usr/libexec/PlistBuddy -c "Print :CFBundleShortVersionString" -c "Print :CFBundleVersion" "$1/Contents/Info.plist" 2>/dev/null | tr '\n' ' '; }
for a in "$H/Downloads"/*.app; do
  n=$(basename "$a"); va=$(appver "$a")
  [ -n "$va" ] || continue
  for inst in "/Applications/$n" "$H/Applications/$n"; do
    if [ -d "$inst" ] && [ "$(appver "$inst")" = "$va" ]; then del "$a"; break; fi
  done
done

section "Total"
if [ "$DRY" = 1 ]; then
  echo "  Liberaria cerca de $(gbs "$TOTAL") (sem contar o brew cleanup)."
else
  echo "  Registrado: $(gbs "$TOTAL") em $LOG"
  echo "  Espaço livre: $(gbs "$FREE_BEFORE") -> $(gbs "$(free_kb)")"
  section "Conferindo as CLIs"
  for c in cursor-agent codex claude; do
    command -v "$c" >/dev/null 2>&1 && printf '  %-13s %s\n' "$c" "$("$c" --version 2>&1 | head -1)"
  done
fi
