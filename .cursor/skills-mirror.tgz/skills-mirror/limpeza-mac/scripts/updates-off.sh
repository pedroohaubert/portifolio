#!/bin/bash
# Desliga o download e a instalação automática de updates do macOS. Precisa de root:
#   bash admin.sh "Desligar updates automáticos do macOS" updates-off.sh [--appstore] [--security]
#   --appstore  também para de atualizar apps da App Store sozinho
#   --security  também desliga "Respostas de Segurança e arquivos do sistema" (não recomendado: são pequenas e corrigem falhas graves)
# O beta NÃO se desliga por aqui: é só em Ajustes > Geral > Atualização de Software > Atualizações Beta.
set -u
SU=/Library/Preferences/com.apple.SoftwareUpdate
defaults write "$SU" AutomaticDownload -bool false
defaults write "$SU" AutomaticallyInstallMacOSUpdates -bool false
for a in "$@"; do
  case $a in
    --appstore) defaults write /Library/Preferences/com.apple.commerce AutoUpdate -bool false ;;
    --security)
      defaults write "$SU" CriticalUpdateInstall -bool false
      defaults write "$SU" ConfigDataInstall -bool false
      ;;
    *) echo "opção desconhecida: $a" >&2; exit 2 ;;
  esac
done
echo "Estado atual:"
defaults read "$SU" | grep -E "^ *(AutomaticDownload|AutomaticallyInstallMacOSUpdates|CriticalUpdateInstall|ConfigDataInstall) "
echo "    App Store AutoUpdate = $(defaults read /Library/Preferences/com.apple.commerce AutoUpdate 2>/dev/null || echo '?')"
