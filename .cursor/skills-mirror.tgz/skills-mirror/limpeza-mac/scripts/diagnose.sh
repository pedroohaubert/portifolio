#!/bin/bash
# Diagnóstico de armazenamento do macOS. Só lê, não apaga nada.
# Uso: bash diagnose.sh [--quick]
#   --quick  pula as partes lentas (arquivos grandes, node_modules e worktrees)
set -u
H="$HOME"
QUICK=0
[ "${1:-}" = "--quick" ] && QUICK=1
TMP=$(mktemp -d -t limpeza-mac-diag)
trap 'rm -rf "$TMP"' EXIT

section() { printf '\n### %s\n' "$1"; }
fmt() { awk -F'\t' '{ printf "%8.2f GB  %s\n", $1 / 1048576, $2 }'; }

# top <pasta> [n]: maiores filhos diretos (ocultos inclusive), a partir de 10 MB
top() {
  [ -d "$1" ] || return 0
  find "$1" -mindepth 1 -maxdepth 1 -exec du -sk {} + 2>/dev/null | awk -F'\t' '$1 >= 10240' | sort -nr | head -n "${2:-15}" | fmt
}

# level <pasta> [n]: maiores subpastas, tiradas do du único da home (até 3 níveis)
level() {
  awk -F'\t' -v pre="$1/" 'index($2, pre) == 1 { r = substr($2, length(pre) + 1); if (r != "" && index(r, "/") == 0) print }' \
    "$TMP/home.du" | sort -nr | head -n "${2:-15}" | fmt
}

# last_edit <pasta>: data da última edição, ignorando dependências e builds
last_edit() {
  local ts
  ts=$(find "$1" \( -name node_modules -o -name .git -o -name .next -o -name dist -o -name build -o -name .venv \) -prune \
    -o -type f -not -name .DS_Store -print0 2>/dev/null | xargs -0 stat -f %m 2>/dev/null | sort -nr | head -1)
  [ -n "$ts" ] && date -r "$ts" +%Y-%m-%d || echo "?"
}

section "Sistema"
sw_vers
build=$(sw_vers -buildVersion)
if [[ $build =~ [0-9][a-z]$ ]]; then
  echo "Build $build termina em letra: provável BETA. Confirme na web."
else
  echo "Build $build sem letra no fim: versão final ou RC. Confirme na web."
fi
df -h / /System/Volumes/Data
diskutil apfs list 2>/dev/null | grep -E "Capacity Not Allocated|\(Role\)|Capacity Consumed" | sed -E 's/^[ |+>-]*//'

section "Atualizações do macOS"
echo "Snapshots locais:"
tmutil listlocalsnapshots / 2>/dev/null | sed 1d | sed 's/^/  /'
PREPARED=0
tmutil listlocalsnapshots / 2>/dev/null | grep -q MSUPrepareUpdate && PREPARED=1
for d in /System/Volumes/Preboot/*/cryptex1/proposed; do
  [ -d "$d" ] && PREPARED=1
done
if [ "$PREPARED" = 1 ]; then
  echo "HÁ UPDATE PREPARADO (snapshot MSUPrepareUpdate e/ou cryptex1/proposed no Preboot). Pacote:"
  grep -a -E '"?(_MasteredVersion|TrainName|_DownloadSize)"? =' /System/Volumes/Update/restore.log 2>/dev/null | tail -3 | sed -E 's/^ */  /'
else
  echo "Nenhum update preparado."
fi
SU=/Library/Preferences/com.apple.SoftwareUpdate
defaults read "$SU" 2>/dev/null | grep -E "^ *(AutomaticDownload|AutomaticallyInstallMacOSUpdates|CriticalUpdateInstall|ConfigDataInstall) " | sed 's/^ */  /'
echo "  App Store AutoUpdate = $(defaults read /Library/Preferences/com.apple.commerce AutoUpdate 2>/dev/null || echo '?')"
echo "Últimas ofertas de update (build com letra no fim = beta):"
defaults read "$SU" FirstOfferDateDictionary 2>/dev/null | awk -F'"' 'NF > 4 { print "  " $4 "  " $2 }' | sort | tail -5
echo "Updates disponíveis (última verificação):"
softwareupdate --list --no-scan 2>&1 | grep -E "Title:" | sed -E 's/^[[:space:]]*/  /'

section "Apps abertos (fechar antes de apagar dados deles)"
lsappinfo visibleProcessList 2>/dev/null | grep -oE '"[^"]+"' | tr -d '"' | paste -sd, - | sed 's/,/, /g'

section "Home: maiores pastas (o painel chama boa parte disso de Documents e Applications)"
du -k -d 3 "$H" 2>/dev/null > "$TMP/home.du"
level "$H" 30
echo "Lixeira: $(du -sh "$H/.Trash" 2>/dev/null | cut -f1)"

section "~/Library"
level "$H/Library" 12
section "~/Library/Application Support"
level "$H/Library/Application Support" 25
section "~/Library/Containers"
level "$H/Library/Containers" 12
section "~/Library/Group Containers"
level "$H/Library/Group Containers" 12
section "~/Library/Caches"
level "$H/Library/Caches" 10

for d in Documents Desktop Downloads Movies; do
  section "~/$d"
  top "$H/$d" 10
done

section "/Applications"
top /Applications 20
section "~/Applications"
top "$H/Applications" 8
section "Homebrew (Cellar)"
top "$(brew --prefix 2>/dev/null || echo /opt/homebrew)/Cellar" 12
section "/Users/Shared"
top /Users/Shared 8
section "/Library"
top /Library 10

section "VMs e discos virtuais"
for p in "$H/Library/Containers/com.docker.docker/Data/vms" "$H/.colima" "$H/.lima" \
  "$H/Library/Application Support/Claude/vm_bundles" "$H/Library/Application Support/CrossOver/Bottles" \
  "$H/Library/Containers/com.utmapp.UTM" "$H/Parallels" "$H/.microsandbox" "$H/.android/avd" \
  "$H/Library/Developer/CoreSimulator/Devices"; do
  [ -e "$p" ] && du -sk "$p" 2>/dev/null
done | sort -nr | fmt

section "Versões acumuladas de ferramentas (o safe-clean.sh mantém só a atual)"
for d in "$H/Library/Application Support/Cursor/User/globalStorage/anysphere.cursor-agent-worker/agent-cli/.local/share/cursor-agent/versions" \
  "$H/.local/share/cursor-agent/versions" "$H/.codex/packages/standalone/releases" "$H/.local/share/claude/versions" \
  "$H/.nvm/versions/node"; do
  [ -d "$d" ] && printf '  %3d versões  %6s  %s\n' "$(find "$d" -mindepth 1 -maxdepth 1 | wc -l)" "$(du -sh "$d" | cut -f1)" "$d"
done
[ -f "$H/.nvm/alias/default" ] && echo "  nvm default: $(cat "$H/.nvm/alias/default")  |  node no PATH: $(command -v node)"

[ "$QUICK" = 1 ] && exit 0

section "Arquivos acima de 400 MB na home"
find "$H" -xdev -type f -size +400M 2>/dev/null | while IFS= read -r f; do
  printf '%s\t%s  (último acesso %s)\n' "$(du -sk "$f" | cut -f1)" "$f" "$(stat -f %Sa -t %Y-%m-%d "$f")"
done | awk -F'\t' '$1 >= 409600' | sort -nr | head -30 | fmt   # du filtra arquivos esparsos e placeholders do iCloud

section "node_modules acima de 50 MB"
find "$H" -maxdepth 6 \( -path "$H/Library" -o -path "$H/.Trash" -o -path "$H/.nvm" -o -path "$H/.npm" -o -path "$H/.bun" \
  -o -path "$H/.cursor/extensions" -o -path "$H/.vscode/extensions" \) -prune -o -type d -name node_modules -prune -print 2>/dev/null \
  | while IFS= read -r d; do
      kb=$(du -sk "$d" 2>/dev/null | cut -f1)
      [ "${kb:-0}" -lt 51200 ] && continue
      p=$(dirname "$d")
      dirty="-"
      git -C "$p" rev-parse --is-inside-work-tree >/dev/null 2>&1 && dirty=$(git -C "$p" status --porcelain 2>/dev/null | wc -l | tr -d ' ')
      printf '%s\t%s  (última edição %s, alterações git: %s)\n' "$kb" "$d" "$(last_edit "$p")" "$dirty"
    done | sort -nr | head -30 | fmt

section "Git worktrees (cópias de trabalho extras; a branch continua no repo)"
{
  find "$H/.cursor/worktrees" -mindepth 2 -maxdepth 2 -type d 2>/dev/null
  find "$H" -maxdepth 5 \( -name node_modules -o -path "$H/Library" -o -path "$H/.Trash" \) -prune \
    -o -type d -path "*/.claude/worktrees" -print 2>/dev/null | while IFS= read -r d; do
      find "$d" -mindepth 1 -maxdepth 1 -type d
    done
} | while IFS= read -r w; do
  [ -f "$w/.git" ] && sed -n 's|^gitdir: \(.*\)/\.git/worktrees/.*|\1|p' "$w/.git"
done | sort -u > "$TMP/mains"
while IFS= read -r m; do
  git -C "$m" worktree list --porcelain 2>/dev/null | sed -n 's/^worktree //p' | tail -n +2 | while IFS= read -r w; do
    [ -d "$w" ] || continue
    printf '%s\t%s  [%s] alterações=%s último commit=%s\n' "$(du -sk "$w" | cut -f1)" "$w" \
      "$(git -C "$w" rev-parse --abbrev-ref HEAD 2>/dev/null)" \
      "$(git -C "$w" status --porcelain 2>/dev/null | wc -l | tr -d ' ')" \
      "$(git -C "$w" log -1 --format=%cd --date=short 2>/dev/null)"
  done
done < "$TMP/mains" | sort -nr | fmt
