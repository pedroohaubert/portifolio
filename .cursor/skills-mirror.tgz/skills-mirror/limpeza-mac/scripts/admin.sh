#!/bin/bash
# Roda um script como root pelo diálogo nativo de senha do macOS.
# O terminal do agente não tem sudo interativo; a senha vai direto para o macOS, nunca pelo chat.
# Uso: bash admin.sh "Motivo mostrado no diálogo" /caminho/script.sh [args...]
set -u
if [ $# -lt 2 ]; then
  echo 'uso: admin.sh "motivo" script.sh [args...]' >&2
  exit 2
fi
reason=$1
shift
out=$(mktemp -t limpeza-mac-admin) || exit 1
cmd="/bin/bash"
for a in "$@"; do cmd+=" $(printf '%q' "$a")"; done
cmd+=" > $(printf '%q' "$out") 2>&1"

# Escapa \ e " para caber numa string AppleScript
as_string() { local s=${1//\\/\\\\}; printf '%s' "${s//\"/\\\"}"; }

osascript -e "do shell script \"$(as_string "$cmd")\" with administrator privileges with prompt \"$(as_string "$reason")\"" >/dev/null
rc=$?
cat "$out"
rm -f "$out"
[ "$rc" -ne 0 ] && echo "admin.sh: osascript saiu com código $rc (senha cancelada ou erro no script)" >&2
exit "$rc"
