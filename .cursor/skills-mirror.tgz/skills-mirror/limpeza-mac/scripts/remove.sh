#!/bin/bash
# Apaga o que o usuário escolheu, mede o que saiu e registra no log.
# Recusa pastas que nunca devem sumir inteiras (home, Documents, Library...).
# Uso: bash remove.sh [--log ARQUIVO] [--conteudo] <caminho>...
#   --conteudo  apaga o que está dentro das pastas, não a pasta (ex.: ~/.Trash)
set -u
LOG="${TMPDIR:-/tmp}/limpeza-mac-deleted.log"
INSIDE=0
while [ $# -gt 0 ]; do
  case $1 in
    --log) LOG=$2; shift 2 ;;
    --conteudo) INSIDE=1; shift ;;
    *) break ;;
  esac
done
H="$HOME"
TOTAL=0

protected() {
  case ${1%/} in
    "" | /System | /System/* | /Library | /Applications | /Users | /Users/Shared | /opt | /opt/homebrew | /private | /usr) return 0 ;;
    "$H" | "$H"/Library | "$H/Library/Application Support" | "$H"/Library/Caches | "$H"/Library/Containers | "$H/Library/Group Containers") return 0 ;;
    "$H"/Applications | "$H"/Desktop | "$H"/Documents | "$H"/Downloads | "$H"/Movies | "$H"/Music | "$H"/Pictures | "$H"/.Trash) return 0 ;;
  esac
  case $1 in /*) return 1 ;; *) return 0 ;; esac   # só caminho absoluto
}

remove() {
  local p=$1 before after freed
  if protected "$p"; then echo "  RECUSADO: '$p'"; return; fi
  [ -e "$p" ] || [ -L "$p" ] || { echo "  não existe: $p"; return; }
  before=$(du -sk "$p" 2>/dev/null | cut -f1)
  rm -rf "$p" 2>/dev/null
  after=0
  if [ -e "$p" ] || [ -L "$p" ]; then after=$(du -sk "$p" 2>/dev/null | cut -f1); fi
  freed=$((${before:-0} - ${after:-0}))
  TOTAL=$((TOTAL + freed))
  printf '%s\t%s\n' "$freed" "$p" >> "$LOG"
  printf '  %-8s %8s GB  %s\n' "$([ "${after:-0}" -gt 0 ] && echo parcial || echo apagado)" \
    "$(awk -v k="$freed" 'BEGIN { printf "%.2f", k / 1048576 }')" "$p"
}

mkdir -p "$(dirname "$LOG")"
for p in "$@"; do
  if [ "$INSIDE" = 1 ]; then
    case ${p%/} in "" | / | "$H" | /System | /System/*) echo "  RECUSADO: esvaziar '$p'"; continue ;; esac
    while IFS= read -r -d '' c; do remove "$c"; done < <(find "$p" -mindepth 1 -maxdepth 1 -print0 2>/dev/null)
  else
    remove "$p"
  fi
done
echo "  total: $(awk -v k="$TOTAL" 'BEGIN { printf "%.2f GB", k / 1048576 }') (log em $LOG)"
