---
name: limpeza-mac
description: Libera espaço em disco no macOS pelo terminal, sem interface. Mapeia onde o armazenamento está (inclusive o que o painel de Armazenamento esconde em Applications, Documents, System Data e macOS), apaga sozinho o que é seguro (caches, versões antigas de ferramentas, builds), resolve beta e updates automáticos do macOS e só pergunta pelo terminal o que for duvidoso. Use quando o Mac estiver com pouco espaço, System Data ou macOS ocupando muito, ou quando pedirem para liberar espaço, limpar o disco, sair do beta do macOS ou desligar atualizações automáticas.
---

# limpeza-mac

O usuário abre o terminal, pede a limpeza e não quer mexer em nada: o agente faz tudo e só pergunta, pelo terminal, o que pode fazer falta. Sem página, sem formulário, sem abrir navegador nem trocar o app em foco.

Os scripts ficam em `scripts/` e rodam com `bash`, não zsh. Guarde log e arquivos temporários no scratchpad da sessão (ou numa pasta de `mktemp -d`), chamada de `$T` abaixo.

## Passos

1. **Diagnóstico:** `bash scripts/diagnose.sh > $T/diag.txt`. Leva cerca de 2 minutos; `--quick` pula arquivos grandes, node_modules e worktrees. Traduza o painel de Armazenamento com a tabela do [REFERENCE.md](REFERENCE.md#painel) e mande uma linha com os 3 a 5 maiores achados.
2. **Limpeza automática:** `bash scripts/safe-clean.sh --dry-run`, confira a lista e rode `bash scripts/safe-clean.sh --log $T/deleted.log`. Ele só apaga o que se regenera ou é sobra comprovada, pula app aberto e versão em uso e no fim confere as CLIs. Não pergunte nada nesta etapa.
3. **macOS:** se o diagnóstico mostrar build beta, ofertas de beta ou update preparado, ou se o usuário pedir, siga [REFERENCE.md › macOS](REFERENCE.md#macos). Confirme na web se a build é beta antes de dizer qualquer coisa ao usuário.
4. **Investigue o que sobrou grande** (`du -sh <pasta>/* | sort -hr | head`) e classifique cada achado pelo [catálogo](REFERENCE.md#catálogo): apagar sozinho, perguntar ou nunca tocar. Pasta desconhecida: pesquise o nome na web antes de classificar.
5. **Pergunte pelo terminal** só o que ficou na dúvida: `AskUserQuestion` com `multiSelect`, até 4 perguntas por chamada e 4 opções em cada, agrupadas por tema (arquivos pessoais, jogos e apps, desenvolvimento, configuração). Cada opção leva o tamanho e o que se perde; ponha "(Recomendado)" no rótulo do que você apagaria. Sem `AskUserQuestion`, faça uma lista numerada e espere a resposta.
6. **Apague o que foi escolhido:**
   - Arquivos e pastas: `bash scripts/remove.sh --log $T/deleted.log <caminhos>`. Para esvaziar uma pasta sem apagá-la (Lixeira), use `--conteudo`.
   - Worktree: `git -C <repo> worktree remove <caminho>`. Só use `--force` se o usuário escolheu perder as alterações.
   - Homebrew: `brew uninstall <fórmula>`. Avise que dependências órfãs saem junto.
7. **Relatório final** no terminal (modelo abaixo).

Mande uma linha de progresso a cada etapa; a limpeza inteira leva vários minutos.

## Regras

- Apague sem perguntar só cache, versão antiga sem uso, build que se regenera e duplicata idêntica (mesmo `md5`). Dado pessoal, jogo, VM, worktree, node_modules e app inteiro: pergunte.
- Não apague dados de app aberto: peça para fechar ou pule.
- Nunca toque em `/System`, Preboot, snapshots `com.apple.os.update-*`, `/System/Library/AssetsV2`, Fototeca, iCloud Drive, Mail, Keychains, histórico de chats de apps (ex.: `state.vscdb` do Cursor) nem em saves de jogos e emuladores.
- Comando de root: `bash scripts/admin.sh "<motivo>" <script>` abre o pedido de senha do próprio macOS. Avise antes e nunca peça a senha no chat.

## Relatório final

- Espaço livre antes e depois.
- O que saiu sozinho e o que saiu por escolha, com GB por grupo.
- Efeitos: o que vai ser recriado ou baixado de novo, o que precisa de `install`, alterações perdidas.
- Pendências (ex.: reiniciar para o macOS descartar um update preparado) e o que ainda dá para liberar.
- Fontes das pesquisas na web.

**Pronto quando:** o espaço livre foi medido antes e depois, nada duvidoso saiu sem resposta do usuário e o relatório diz o que mudou e o que ficou pendente.
