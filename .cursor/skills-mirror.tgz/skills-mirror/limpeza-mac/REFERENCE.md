# Referência da limpeza-mac

## Painel

O painel Ajustes › Geral › Armazenamento agrupa por tipo, não por pasta. Por isso o usuário estranha os números.

| Categoria | O que costuma ser de verdade |
|---|---|
| Applications | Os .app e os dados deles em `~/Library/Application Support` e `~/Library/Containers`: jogos da Steam, VMs (Claude Cowork, Docker, CrossOver), versões acumuladas de CLIs |
| Documents | Tudo na home que não cai em outra categoria: projetos, `node_modules`, `~/.cache`, `~/.cursor`, `~/.codex`, ROMs, gravações de tela. Não é só `~/Documents` |
| System Data | Caches, logs, discos virtuais (`Docker.raw`) e arquivos de update em preparação |
| macOS | Volume do sistema mais o Preboot. Um update preparado aparece aqui |

## Catálogo

### Apagar sozinho (o `safe-clean.sh` já faz)

- **Versões antigas de CLIs:** worker do Cursor (`Application Support/Cursor/User/globalStorage/anysphere.cursor-agent-worker/agent-cli/.local/share/cursor-agent/versions`, acumula uma versão de ~0,6 GB por semana), `~/.local/share/cursor-agent/versions`, `~/.codex/packages/standalone/releases`, `~/.local/share/claude/versions`. Fica a versão para onde o link aponta e qualquer uma em uso.
- **Discord:** `app-*` antigos e `download` em `Application Support/discord`.
- **Caches de editores fechados:** `CachedData`, `Cache`, `Code Cache`, `GPUCache` e `logs` do Cursor e do VS Code.
- **Stremio:** `Application Support/stremio-server/stremio-cache` (chegou a 6 GB).
- **Xcode:** `~/Library/Developer/Xcode/DerivedData`.
- **`~/Library/Caches`:** tudo, menos `ms-playwright` e os caches de apps abertos.
- **Gerenciadores de pacote:** `uv cache clean` (chegou a 8,5 GB em duas semanas), `npm cache clean --force`, `pnpm store prune`, `bun pm cache rm`, `yarn cache clean`, `brew cleanup --prune=all`.
- **Next.js:** `.next/dev` e `.next/cache` nos projetos.
- **App repetido em Downloads:** `.app` com a mesma versão de um já instalado.

### Perguntar

| Item | Onde ou como achar | Como apagar | O que se perde |
|---|---|---|---|
| Lixeira (Recomendado) | `~/.Trash`; liste o que tem | `remove.sh --conteudo ~/.Trash` | Só o que o usuário já jogou fora |
| Gravações de tela órfãs (Recomendado) | `~/Library/Group Containers/group.com.apple.screencapture/ScreenRecordings` | `remove.sh --conteudo` | Temporários que nunca foram salvos |
| Duplicatas (Recomendado) | mesmo tamanho e `md5 -q a b` igual | `remove.sh` na cópia | Nada |
| node_modules parados (Recomendado se parado há meses) | diagnóstico mostra a última edição | `remove.sh` | Precisa de `install` ao voltar |
| Node antigo do nvm | `~/.nvm/alias/default`, `command -v node`; os CLIs globais dele estão no PATH? | `remove.sh ~/.nvm/versions/node/<versão>` | CLIs globais daquela versão |
| Worktrees sem alterações (Recomendado) | diagnóstico, `alterações=0` | `git worktree remove` | Nada; a branch fica |
| Worktrees com alterações | diagnóstico, `alterações>0` | `git worktree remove --force` | As alterações não commitadas |
| Fórmulas grandes do Homebrew | `du -sh $(brew --prefix)/Cellar/*`, `brew uses --installed <f>` | `brew uninstall` | O comando e dependências órfãs |
| Navegadores do Playwright | `~/Library/Caches/ms-playwright` | `remove.sh` | Baixados de novo pelo MCP do Playwright |
| Disco da VM do Claude Cowork | `Application Support/Claude/vm_bundles/claudevm.bundle/rootfs.img` | `remove.sh` só nesse arquivo, com o Claude fechado | Recriado do `rootfs.img.zst`; perde o que foi instalado na VM |
| Dados do Docker | `~/Library/Containers/com.docker.docker/Data/vms` | `remove.sh` com o Docker fechado; para desinstalar, `/Applications/Docker.app/Contents/MacOS/uninstall` | Imagens, containers e volumes (bancos locais) |
| Garrafas do CrossOver | `Application Support/CrossOver/Bottles/<garrafa>` | `remove.sh` | Os programas Windows da garrafa |
| Jogos da Steam | `Application Support/Steam/steamapps/common/<Jogo>` e `appmanifest_<id>.acf` (ache o id com `grep installdir`) | `remove.sh` nos dois | Baixa de novo; o progresso costuma ficar na nuvem |
| Minecraft e launchers | `Application Support/minecraft` (veja `saves/`), `tlauncher` | `remove.sh` | Mods e mundos locais |
| Restos de app desinstalado | pasta sem o .app correspondente (ex.: `Movies/CapCut`, `/Users/Shared/Riot Games`) | `remove.sh` | Configurações e cache |
| ROMs | `.nsp`, `.xci`, `.nds`; o mesmo jogo em dois formatos é duplicata | `remove.sh` | O jogo; os saves do emulador ficam |
| Gravações e vídeos grandes | Mesa e Filmes; mostre a data de cada um | `remove.sh`, um por um | O vídeo |

### Nunca tocar (nem oferecer)

- `/System`, Preboot, snapshots `com.apple.os.update-*` e `/System/Library/AssetsV2`: protegidos pelo SIP, e mexer pode impedir o Mac de ligar.
- Fototeca: limpar pelo app Fotos. WhatsApp: Ajustes › Armazenamento no próprio app. Diga isso no relatório.
- iCloud Drive (`~/Library/Mobile Documents`), Mail e Keychains.
- Estado de apps, como o `state.vscdb` do Cursor (histórico de chats).
- Saves e chaves de emuladores (ex.: `Application Support/Ryujinx`).
- `/private/var/db` (logs e diagnósticos do sistema): o macOS gerencia.

## macOS

**Beta ou não?** Build com letra minúscula no fim (`26A5416b`) é beta; sem letra (`26A428`) é final ou RC. Confirme na web com "macOS <versão> <build>". No caso real, o usuário achava que estava no beta, mas a build já era a final; só a inscrição no beta continuava ativa e já tinha baixado o beta seguinte. O diagnóstico lista as últimas builds oferecidas (`FirstOfferDateDictionary`).

**Sair do beta:** o `seedutil` não funciona mais. O único caminho é Ajustes › Geral › Atualização de Software › Atualizações Beta (i) › Desativado. Peça ao usuário pelo terminal; se ele quiser, abra o painel com `open "x-apple.systempreferences:com.apple.Software-Update-Settings.extension"`. Confira depois com `softwareupdate --list`: nenhuma build beta pode aparecer.

**Voltar de um beta de verdade para a versão final:** com o beta desligado, a próxima versão pública chega como update normal quando passar da build instalada. Voltar na hora exige apagar e reinstalar pelo Recovery ou restaurar um backup de antes do beta. É destrutivo: só com o usuário de acordo e com backup feito.

**Updates automáticos:** `bash scripts/admin.sh "Desligar updates automáticos do macOS" scripts/updates-off.sh`. O script desliga o download e a instalação do macOS. `--appstore` também desliga os apps da App Store. `--security` também desliga "Respostas de Segurança e arquivos do sistema"; não recomendo, então pergunte antes. O macOS continua avisando quando há update.

**Update preparado:** o snapshot `com.apple.os.update-MSUPrepareUpdate`, o `cryptex1/proposed` no Preboot e o pacote em `AssetsV2` ocupam de 10 a 15 GB. Não apague à mão. Com o beta desligado, peça para reiniciar. No caso real, o pacote sumiu sozinho depois disso (o Preboot foi de 21,8 GB para 11 GB). Rode o diagnóstico de novo para confirmar.

## Pegadinhas

- O zsh aborta o comando inteiro quando um glob como `.[!.]*` não acha nada ("no matches found") e trata `==` como comando. Rode com `bash` e use `find -mindepth 1 -maxdepth 1`.
- O macOS não tem `timeout`.
- O `ls` mostra o tamanho aparente: arquivo esparso (`Docker.raw` com 32 GB aparentes e 9 GB reais) e placeholder do iCloud enganam. Meça com `du`.
- Binário chamado por link (`claude`, `cursor-agent`) não mostra o caminho real no `pgrep -f`. Para saber se está em uso, use `lsof -t -- <arquivo>` ou `lsof -t +D <pasta>`.
- `brew uninstall` faz autoremove: no caso real, desinstalar o code-server levou o `node@22` junto.
- Sem Acesso Total ao Disco para o app do terminal, o `du` subconta pastas protegidas.
- O `sudo` não pede senha no shell do agente; use o `admin.sh`.
