---
name: canvas
description: A Cursor Canvas is a live React app that the user can open beside the chat. You MUST use a canvas when the agent produces a durable standalone artifact outside the transcript that the user may revisit, refine, or share — reports, dashboards, documents, data-heavy investigations, or repeatable tools. Especially prefer a canvas when presenting results from MCP tools (Datadog, Databricks, Linear, Sentry, Slack, etc.) where a durable artifact is the deliverable — render it in a rich canvas rather than dumping it into a large markdown table or code block. Do not use a canvas for an immutable visual output that belongs inside the transcript. You MUST also read this skill whenever you create, edit, or debug any .canvas.tsx file.
metadata:
  surfaces:
    - ide
    - cloud
---

A canvas is a single `.canvas.tsx` module persisted by the `WriteCanvas` / `ReadCanvas` tools. Call them directly — never via `GetDynamicTools`, `CallDynamicTool`, or MCP. Do **not** create or edit `source.canvas.tsx` with the write-file tool, and do **not** mint a UUID path under a FUSE canvases root. Follow the workflow below in order.

## Workflow

### 1. Decide whether to use a canvas

The trigger is **user intent**, not response shape. Ask: would the user benefit from viewing this output as its **own durable standalone artifact outside the transcript**, separate from the chat? If the output is a means to an end (a drafted message, a code fix, a dashboard in another tool), skip the canvas.

**Use a canvas when the agent produces new standalone analytical output:**
- Quantitative analyses and metrics breakdowns (e.g. "send 500 requests and tell me how many fail")
- Billing or account investigations that surface structured findings from database queries
- Security audits or architecture reviews with categorized findings
- Cross-system data analyses and overlap reports
- Structured data from MCP tools (Databricks, Datadog, etc.) where a durable standalone artifact is the deliverable
- Financial analyses, margin decompositions, usage trend reports
- Large tables the user wants to revisit or refine

**Do NOT use a canvas when:**
- The user asks for work in a **specific tool** — "create a Datadog dashboard" means give them a Datadog dashboard, not a canvas
- The user has a **specific deliverable** — "draft a support response", "fix this code", "make this PR"
- The user is **working within an existing artifact** — improving an HTML dashboard, editing an existing file
- The user is doing **targeted debugging** or active development, even if structured findings emerge along the way
- An immutable visual output belongs inside the transcript rather than in a durable standalone artifact
- Short factual answers, one-off file edits, or quick clarifying questions
- MCP tools are queried as an **intermediate step** for a different deliverable (e.g. querying Stripe to draft a support reply)

### 2. Write the canvas

**Location.** There is no file path. Create or overwrite a canvas by calling `WriteCanvas`:

- `contents` — the full self-contained `.canvas.tsx` module. Overwrites the whole canvas; send the complete file, not a patch.
- `canvas_id` — omit to create a new canvas. Pass the id of an existing canvas in this run's store to overwrite it in place.
- `title` — provide it when creating a new canvas. Omit to keep an existing canvas's title.

To read an existing canvas, call `ReadCanvas` with `canvas_id` or the canvas `url`. Never Glob, Find, or Search for `*.canvas.tsx` or a canvases root.

**File rules:**
- Exactly one `.canvas.tsx` file per canvas. Never create helper files, style files, or supporting modules.
- Import **only** from `cursor/canvas`. No relative imports, no npm packages, no Node built-ins.
- Default-export the top-level component.
- Embed all data inline. **No `fetch()`, no network calls.**

**Never render empty states.** A canvas exists to show real content. If a section, chart, table, or component has no data to display, **omit it** — do not render it with placeholder text ("Add header here", "TODO", "Example"), a "No data" message, an empty array, zeroed rows, or an empty chart frame. If the entire canvas would be empty because you don't have the underlying data, do not produce a canvas — tell the user what's missing and ask for it instead.

**Label every plot.** Charts and tables must be self-describing — a reader looking at the canvas alone should know exactly what they're seeing. For every plot include:
- A title naming the **specific metric** (not "Metrics" — "API error rate by service").
- **Axis labels with units** on both axes (e.g. "Date", "Latency (ms)").
- A **legend** when more than one series is shown, with the exact series names from the source data.
- The **source and time range** in a small caption (e.g. "Source: Datadog · last 7 days"). If a value is a transformation (mean, p95, normalized, smoothed), say so in the label.

**Component discovery:** prefer built-in `cursor/canvas` components over hand-rolled markup. The full public surface (components, hooks, prop types, tokens) is declared in `~/.cursor/skills-cursor/canvas/sdk/index.d.ts` and its sibling `.d.ts` files — read them when you need exact exports, prop shapes, or hook signatures rather than guessing. Referencing an export that does not exist is the most common runtime error.

Apply the Design guidance below as you write, and complete its Pre-delivery self-check before delivering the canvas.

### 3. Reference the canvas

The `WriteCanvas` / `ReadCanvas` result reports a `url`. That url, exactly as returned, is the only canvas reference you give the user — use it wherever you mention the canvas; Cursor surfaces resolve it to an openable canvas.

**Updating.** Call `WriteCanvas` again with the same `canvas_id` and the full new `contents`. Do not edit a path on disk.

## Design guidance

Be creative. The SDK gives you expressive building blocks — use them in whatever combination best serves the content. But avoid slop: no gradients, no emojis, no box-shadows, no rainbow coloring. Cursor canvases are flat, minimal, and purposeful.

### Visual hierarchy

Not everything deserves equal treatment. Primary content gets more space, larger headings, and accent color. Supporting content stays compact. Squint test: blur your eyes — can you tell what matters?

**Color.** All colors from `useHostTheme()` tokens — read its JSDoc in the SDK declarations for the return shape and usage pattern. No hardcoded hex. Use accent color deliberately, not on everything.

### Slop patterns — forbidden

These specific patterns produce low-quality output. If 2+ are present, redesign.

- **Gradients** — no `linear-gradient`, `radial-gradient`, `background-clip: text`.
- **Emojis** — no emoji as icons, status indicators, bullets, or section markers.
- **Box shadows** — no `box-shadow`. Flat surfaces only.
- **Wall of identical cards** — every section wrapped in the same card style with no variation. Mix open sections with cards.
- **Rainbow coloring** — a different color on every element. Most elements are neutral; color is used sparingly with purpose.
- **Giant text** — font sizes above H1 (24px), or bold text stuffed in CardHeader.
- **Decorative borders** — colored borders on every element. Borders are structural (subtle stroke tokens), not decorative.

### Pre-delivery self-check

Before returning canvas code, verify:
1. Does the layout have visual hierarchy? One thing should stand out.
2. Is there variety in the composition? Not just a single column of uniform blocks.
3. Slop check: scan for the forbidden patterns above.

## Introducing the canvas

Whenever you mention a canvas — one you created, updated, or want the user to open — **always** include a markdown link to the tool result's `url` (for example, `[Billing Review](<url>)`), with a short descriptive label.

After a successful `WriteCanvas` call, when you mention this canvas outside Cursor (Slack, email, Notion, Grok Bot), link `https://cursor.com/canvas/store-2902a162-78a4-423e-8b20-bf9d18b68e80/<canvasId>` (substitute the tool's `canvas_id`). Inside Cursor, keep linking the tool result's `url`.

When you create a canvas, add a short note in your chat response telling the user they can open it, with that link. If the user didn't ask for a canvas, include one sentence explaining why you chose it over plain text.

Keep this to one or two sentences. On later mentions, still link the canvas but skip the extra introduction.

## Troubleshooting

If a canvas is missing, blank, or the user cannot open it:

- **No url in the tool result** — the write did not succeed. Read the tool's failure reason and diagnostics; fix `contents` and call `WriteCanvas` again. Do not fall back to a write-file path.
- **Validation failure** — type, compile, and size problems are reported on the tool result; fix and re-call `WriteCanvas`. The last good version keeps serving.
- **Edits don't show up** — only a successful `WriteCanvas` persists; do not expect a write-file save to compile.
