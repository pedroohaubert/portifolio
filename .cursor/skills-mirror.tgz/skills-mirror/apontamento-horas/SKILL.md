---
name: apontamento-horas
description: Monta os apontamentos diários de tarefas para o lançamento de horas, um parágrafo por dia útil escrito a partir dos commits e PRs do próprio usuário no repositório, inclusive nos dias que ficaram sem commit. Use quando pedirem o que foi feito em um dia ou num mês, apontamento ou lançamento de horas, report de atividades ou o resumo para o relatório da empresa.
---

# apontamento-horas

Quem lê é o gestor dentro do sistema de lançamento de horas: não acompanhou as tasks e não abre o repositório. Cada dia vira um parágrafo de 2 a 3 frases, em primeira pessoa, pronto para colar. Serve para um dia só ou para o mês inteiro, em qualquer repositório; os exemplos daqui vêm de um projeto de viabilidade imobiliária.

## Passos

1. **Ache os e-mails do usuário no repo:** `git log --all --format='%ae' | sort | uniq -c | sort -rn`. Quase sempre são dois, o corporativo (que assina os "Merged PR") e o pessoal. Use os dois daqui em diante.
2. **Puxe os commits do período com o corpo inteiro,** não só o assunto:
   `git log --all --since=AAAA-MM-DD --until=AAAA-MM-DD --author='<email1>\|<email2>' --regexp-ignore-case --date=format:'%Y-%m-%d' --format='%n@@@ %ad|%h|%s%n%b'`
   O corpo é onde estão o motivo da mudança e quem pediu. O parágrafo sai dele; o assunto sozinho rende texto vago.
3. **Liste os dias úteis do período** e separe os que ficaram sem commit do usuário.
4. **Reconstrua esses dias pelo entorno,** nesta ordem: `git reflog --date=format:'%Y-%m-%d %H:%M' --format='%ad | %gs'` (branch aberta no fim do dia é investigação que virou entrega no dia seguinte), o PR do dia seguinte, as datas citadas dentro dos corpos de commit ("Controladoria (Carol, 2026-08-13)") e as pastas de rascunho ou docs criadas por perto. Escreva o dia com o que essa evidência sustenta. Não entregue "sem commit no dia" como se fosse o conteúdo do dia.
5. **Escreva cada dia** nesta ordem: o que entreguei, o que aquilo resolvia para quem usa e onde parou (mergeado, promovido para homologação, frente aberta). Dia cheio vira uma frase por frente, nunca uma lista. Se o usuário ditar a abertura do parágrafo, use as palavras dele.
6. **Revise** com a régua abaixo, parágrafo por parágrafo.
7. **Entregue** os dias em ordem, cada um com a data como rótulo e nada mais. Se houver dia reconstruído, diga numa linha no fim quais são e em que evidência se apoiam, para o usuário trocar pelo que lembrar. O parágrafo único do mês só entra se pedirem o relatório mensal.

## Régua do texto

- **2 a 3 frases por dia.** Passou disso, corte o detalhe que só o time de desenvolvimento entende.
- **Primeira pessoa, no passado:** corrigi, implementei, documentei, promovi.
- **Linguagem de quem usa o sistema:** nome de tela, aba, campo, estudo e quem pediu. Sem coordenada de célula, nome de função, arquivo, variável ou branch. Número de PR pode ficar.
- **Registro profissional.** É relatório de horas, não conversa. Sem piada, sem apelido de bug, sem "aquele do...", sem verbo de bastidor como "aposentei" ou "matei".
- **Formatação só na data.** Sem negrito no meio da frase, sem itálico, sem lista dentro do dia, sem emoji.
- **Travessão nunca.** Vírgula, ponto, dois-pontos ou parênteses.
- **Todo fato vem do commit, do PR ou do reflog,** menos os dias reconstruídos do passo 4. Número, nome e data que não estão lá não entram.

## Antes e depois

| Defeito | Assim não | Assim sim |
|---|---|---|
| Técnico demais | "Corrigi o AB15: o C1022 lia VGV bruto em vez da coluna TOTAL RECEITA e o C1024 não subtraía os reembolsos da permuta." | "Corrigi o Custo do Terreno a VP, que vinha calculado sobre o valor bruto e sem descontar os reembolsos da permuta." |
| Coloquial demais | "Corrigi o item 16 do backlog, aquele das colunas deslocadas." | "Corrigi o item 16 do backlog da Controladoria, que tratava das colunas deslocadas na exportação." |
| Grande demais | Duas frases sobre a causa, mais a lista do que mudou em cada aba do arquivo. | A entrega, o efeito para quem usa e onde parou. O resto fica no PR. |
| Vazio | "Sem commit no dia." | "Fiz o triage do backlog do Gaivota, separando divergência de fórmula de divergência de cadastro, e abri as duas frentes que entreguei no dia seguinte." |

## Exemplo

18/8 Entreguei três itens do estudo Gaivota. A quantidade total de unidades da Capa passou a incluir tipologia 100% permutada, indo de 68 para 71, e a aba Perfil de Venda deixou de sair em branco quando o estudo não tem perfil cadastrado. Documentei também que esse estudo em homologação está sem perfil vinculado, o que é cadastro e não erro de cálculo.

**Pronto quando:** o gestor entende cada dia sem abrir o sistema, nenhum parágrafo passa de três frases, não há termo de código no texto e os dias reconstruídos estão sinalizados no fim.
