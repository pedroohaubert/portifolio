---
name: business-decision-questionnaire
description: Turns decisions already made or implemented into a concise, humanized questionnaire for a business expert. Use when explicitly invoked to validate business rules, calculations, assumptions, or alternatives after planning or implementation.
disable-model-invocation: true
---

# Business Decision Questionnaire

Turn decisions from plans, tickets, research, PRs, or implemented work into a message that one business expert can answer quickly.

## Process

### 1. Understand the send

Use the conversation context first. Ask only for missing information:

1. Who will receive the message? Get their name, role, and familiarity with the subject.
2. What must their answers confirm or clarify?

Do not ask the user for facts that can be recovered from the conversation, repository, tickets, or research.

### 2. Recover the decisions

Read the relevant artifacts and separate:

- facts supported by evidence;
- decisions or assumptions already made;
- contradictions or alternatives that remain plausible.

Keep only points that affect a business rule, formula, timing, classification, accounting treatment, or user-visible outcome.

Omit code structure, file names, function names, tests, migrations, branches, and implementation mechanics. Omit layout choices unless they change the business meaning.

### 3. Turn decisions into questions

Order the questions by business impact. Use one rule per question.

Each question should:

- give only the context needed to answer;
- state the current interpretation in first-person singular;
- include a formula or worked example when it makes the rule clearer;
- name one or two plausible alternatives when there is real uncertainty;
- end with a direct request to confirm the rule or provide the correct one.

Use natural variation such as:

- "Entendi que..."
- "Minha leitura foi..."
- "Considerei..."
- "Supus que..."
- "Fiquei na dúvida se..."

Do not repeat "penso" or "está correto?" mechanically. Do not present the chosen option as settled fact.

### 4. Make it easy to answer

Write in the recipient's business vocabulary. Prefer familiar field, report, process, and accounting names over technical terminology.

Every question should be answerable with:

- "correto";
- one of the alternatives shown; or
- a short correction.

If a question needs a long explanation, split it.

### 5. Humanize the message

- Write as the user in first-person singular: "estou", "entendi", "considerei".
- Address the recipient naturally by name.
- Keep sentences short and plain.
- Avoid excessive headings, bold text, tables, boilerplate, and formal questionnaire language.
- Do not use em dashes or en dashes.
- Do not invent facts, values, formulas, names, or examples.

### 6. Output

Unless the user asks for a file, return only one fenced `text` block that is ready to copy into Teams or another chat.

Use this shape:

```text
Oi [nome], tudo bem?

Estou revisando [contexto curto]. Cheguei às interpretações abaixo, mas fiquei com dúvida entre algumas opções. Você consegue me ajudar?

1. [Regra em linguagem de negócio]

Minha leitura foi: [opção atual].

A outra possibilidade seria [alternativa real]. Qual regra está correta?

2. [Próxima regra]
...
```

Do not add a draft, audit, preface, or summary outside the copy block.

## Final check

Before answering, confirm that:

- every claim came from the source material or the user;
- only business and calculation decisions remain;
- the message uses first-person singular;
- alternatives are concrete and plausible;
- each question is concise and independently answerable;
- the final response contains one copy-ready text block and no extra commentary.
