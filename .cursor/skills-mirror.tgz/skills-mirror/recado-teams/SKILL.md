---
name: recado-teams
description: Escreve a mensagem que o usuário vai colar no Teams para o negócio ou para um colega, em parágrafos curtos e naturais. Use quando pedirem um texto, recado, aviso ou explicação para mandar a alguém (por que algo aconteceu, o que mudou, uma pergunta a uma pessoa), ou para encurtar ou reorganizar uma mensagem dessas. Recado de task concluída é da skill task-recap, quando o repo tiver.
---

# recado-teams

A mensagem sai pronta para colar. Quem lê não acompanhou a conversa, então ela conta o caso do começo, na ordem em que as coisas aconteceram, e fecha com o que acontece agora.

## 1. Leitor

Defina para quem é antes de escrever. O leitor decide o vocabulário:

| Leitor | Vocabulário |
|---|---|
| Negócio (Controladoria, operação, quem testa) | Nomes de tela, campo e item da planilha. Branch vira "pacote", release vira "versão", deploy vira "subir para produção". |
| Colega de desenvolvimento | Termos de git e nomes de arquivo, quando ajudam. Número de PR. |
| Privado de uma pessoa | O mais curto dos três, falando direto com ela. |
| Grupo | Abre com "Pessoal," e explica o suficiente para quem chegou agora. |

Se o pedido não diz o leitor, deduza da conversa (quem reclamou, quem vai receber) e siga.

## 2. Fatos

Junte da conversa o que aconteceu, a causa, a consequência e o que vai ser feito. Cada número, data, nome e item da mensagem precisa ter saído da conversa ou do que você conferiu nela. Item da planilha vai com o número e o assunto entre parênteses na primeira vez: "o 34 (ociosidade e relacionamento por fase)".

## 3. Escrever

Parágrafos curtos, de duas a quatro frases cada, nesta ordem:

1. **O que aconteceu**, na primeira frase, sem preâmbulo.
2. **Por quê.** A cadeia de causa inteira, um passo por frase: "estavam no mesmo pacote", "só o 21 estava aprovado", "por isso o 34 ficou de fora". É a parte que o leitor precisa para não achar que foi descuido.
3. **O que vale agora** ou o que vai ser feito, com quem e quando.
4. **Pergunta ou pedido**, se houver, no fim.

Escreva como um colega fala:

- frases corridas, sem lista, sem negrito e sem título;
- vírgula, ponto ou parênteses no lugar de travessão;
- primeira pessoa ("tirei", "vou subir") quando foi o usuário que fez.

**Tamanho.** O padrão são três ou quatro parágrafos curtos. Quando pedirem "mais curto", corte exemplos, datas secundárias e fatos laterais, e mantenha cada passo da cadeia de causa: o texto curto que pula um passo fica confuso, e o leitor pede para alongar de novo. Quando pedirem "mais longo" ou disserem que ficou confuso, devolva o passo da causa que faltou, separado em frase própria.

## 4. Entregar

A mensagem sozinha, sem comentário antes, em texto puro: parágrafos normais da resposta, sem `>` de citação, sem bloco de código e sem negrito. O usuário copia e cola no Teams, e a barra da citação vira caractere estranho no texto colado. Se algo ficou de fora de propósito (um fato que confundiria o leitor, uma pendência do usuário), diga numa linha abaixo da mensagem, depois de uma linha em branco.

**Pronto quando:** quem não acompanhou entende o que aconteceu e por quê só lendo a mensagem, cada fato dela saiu da conversa, e não sobrou termo que o leitor não usa.

## Exemplo

Pedido: explicar para o grupo do negócio por que o item 34 não subiu na release. A resposta entregue é só o texto abaixo, do jeito que está, sem citação:

Pessoal, explico por que o 34 (ociosidade e relacionamento por fase) não subiu.

O 16, o 21 e o 34 mexem na mesma parte do sistema, então foram desenvolvidos juntos, num pacote só. Na versão de 07/10, o 21 estava aprovado, mas o 34 ainda estava em homologação. Por isso tirei o 34 do pacote e levei só o resto. O 16 acabou indo junto com o 21, mesmo sem aprovação, porque os dois usam a mesma regra e não dava para separar um do outro.

Depois disso a única versão foi a de 09/10, que levou só a correção da Margem Bruta. O 34 ficou na homologação esperando a próxima.

Vou subir o 34 amanhã. Daqui para frente, cada item vai ter o seu próprio pacote, para um não subir puxando outro nem ficar preso por causa dele.
